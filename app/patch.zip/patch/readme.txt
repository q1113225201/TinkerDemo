命令
java -jar tinker-patch-cli-1.7.7.jar -old old.apk -new new.apk -config tinker_config.xml -out output_path

前提
在统计目录下放置old.apk和new.apk
在tinker_config.xml中配置需要的签名